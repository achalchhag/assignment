// Implement method overloading by creating methods for different data types.
package assignmet;

public class methods2 {
	
	public void print(int a) {
		System.out.println("Value of A in Int is "+a);
	}
	
	public void print(double a)
	{
		System.out.println("Value of A in double is "+a);
	}
	public void print(String a) {
		System.out.println("Value of A in String is "+a);
	}

	public static void main(String[] args) {
		methods2 m= new methods2();
		m.print(1);
		m.print(123456789);
		m.print("Hello");

	}

}
