//Implement a simple menu-driven program using a switch-case.

package assignmet;

public class CFS2 {

	public static void main(String[] args) {
		System.out.println("1.1st Java");
		System.out.println("2.2nd Python");
		System.out.println("3.exit");
		int choice=2;
		switch(choice)
		{
		case 1:
			System.out.println("Hello Java");
			break;
		case 2:
			System.out.println("Hello Python");
			break;
		case 3:
			System.out.println("Exiting Program");
			System.exit(0);
		default:
			System.out.println("Enter a valid choice");

		}

	}

}
