//o Create an abstract class and implement its methods in a subclass.
package assignmet;

public class Interface1 extends detail {

	public static void main(String[] args) {
		Interface1 i= new Interface1();
		i.data();
		i.sensitivedata();
		

	}

	@Override
	void sensitivedata() {
		System.out.println("Bank Details");
		
	}

}

abstract class detail{
	public void data() {
		System.out.println("Name and email");
	}
	
	abstract void sensitivedata();
}
