//Implement method overriding to show polymorphism in action.

package assignmet;

class parents1{
	public void displays()
	{
		System.out.println("This is parent class");
	}
}

class child extends parents1{
	public void display()
	{
		System.out.println("This is Child class");
	}
}
public class oops3 {

	public static void main(String[] args) {
		
		child c= new child();
		c.display();
		c.displays();

	}

}

