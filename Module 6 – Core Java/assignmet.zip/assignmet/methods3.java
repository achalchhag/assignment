// Create a class with static variables and methods to demonstrate their use.
package assignmet;

public class methods3 {
	static int a=0;
	
	public static void increase() {
		a++;
		System.out.println("After Increment "+a);
	}
	
	public static void display() {
		System.out.println("Static Value of a is "+a);
	}

	public static void main(String[] args) {
		
		methods3.display();
		methods3.increase();

	}

}
