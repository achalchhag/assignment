//Create a HashMap to store and retrieve key-value pairs.
package assignmet;

import java.util.HashMap;
import java.util.Map;

import collection.pojo;

public class Collectionsframework3 {

	public static void main(String[] args) {
		pojo p= new pojo(1, "Java");
		pojo p1= new pojo(2,"Java2");
		HashMap<Integer, pojo> al= new HashMap<Integer, pojo>();
		al.put(1,p);
		al.put(2,p1);
		
		for(Map.Entry<Integer,pojo> m:al.entrySet())
		{
			int a= m.getKey();
			pojo j=m.setValue(p);
			System.out.println(a+ " "+j.id+ " "+j.name);
		}

	}

}
