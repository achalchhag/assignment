//Write a program to perform matrix addition and subtraction using 2D arrays
package assignmet;

public class arrays1 {

	public static void main(String[] args) {
		int a[][] = {{1,2},{3,4}};
		int b[][] = {{5,6},{7,8}};
		int c[][] = {{0,0},{0,0}};
		

		System.out.println("Addition of matrix is ");
		for(int i=0;i<2;i++)
		{
			for(int j=0;j<2;j++)
			{
				c[i][j]=a[i][j]+b[i][j];
				System.out.print(c[i][j]+" ");
			}
			System.out.println(" ");
		}
		
		System.out.println("Subtraction of matrix is ");
		for(int i=0;i<2;i++)
		{
			for(int j=0;j<2;j++)
			{
				c[i][j]=b[i][j]-a[i][j];
				System.out.print(c[i][j]+" ");
			}
			System.out.println(" ");
		}
	}
}
