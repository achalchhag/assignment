//o Implement a file copy program using FileInputStream and FileOutputStream.
package assignmet;

public class JavaInputOutput2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
