//Write a program demonstrating single inheritance.
package assignmet;
class oops1 {
    public void display() {
        System.out.println("This is Parent class");
    }

    static class childs extends oops1 {
        public void displayc() {
            System.out.println("This is Child Class");
        }
    }

    public static void main(String[] args) {
        childs c = new childs();
        c.display();
        c.displayc();
    }
}
