//Create a calculator using arithmetic and Relational Operator.
package assignmet;
public class Datatype2calculator {

	public static void main(String[] args) {
		System.out.println("Basic Calculator");
		double num1=20,num2=30,num3=0;
		num3=num1+num2;
		System.out.println("Addition is"+" "+num3);
		
		num3=num2-num1;
		System.out.println("Subtraction is"+" "+num3);
		
		num3= num1*num2;
		System.out.println("Multiplication is "+" "+num3);
		
		num3=num2/num1;
		System.out.println("Divide is "+" "+num3);
		
		System.out.println("Relational Operator");
		if(num1>num2)
		{
			System.out.println("Num 1 is greater");
		}
		else {
			System.out.println("Num 2 is greater");
		}
	}

}
