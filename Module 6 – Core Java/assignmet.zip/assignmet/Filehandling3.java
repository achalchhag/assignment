// Create a program that demonstrates object serialization and deserialization
package assignmet;

public class Filehandling3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
