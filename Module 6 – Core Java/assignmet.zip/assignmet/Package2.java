//Demonstrate the use of different access modifiers within the same package and across different packages
package assignmet;

public class Package2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
