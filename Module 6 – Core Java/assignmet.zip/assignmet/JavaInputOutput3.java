//o Create a program that reads from one file and writes the content to another file.
package assignmet;

public class JavaInputOutput3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
