// Write a program to display the series using a loop.

package assignmet;

public class CFS3 {

	public static void main(String[] args) {
		int n = 10,n1=0,n2=1;
		System.out.println("Fibonaci series till "+ n +" terms:");
		for(int i=1;i<=n;++i) {
			System.out.print(n1	 + " ");
			int n3=n1+n2;
			n1=n2;
			n2=n3;
		}

	}

}
