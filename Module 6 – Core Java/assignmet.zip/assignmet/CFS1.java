//Write a program to find if a number is even or odd using an if-else statement.

package assignmet;

public class CFS1 {

	public static void main(String[] args) {
		int a=20;
		if(a%2==0)
		{
			System.out.println("The number is even");
		}
		else
		{
			System.out.println("The number is odd");
		}

	}

}
