//Write a program to create and initialize an object using a parameterized constructor.

package assignmet;

class details{
	int id;
	String name;
	
	public details(int id,String name) {
		this.id=id;
		this.name=name;
	}
	
	public void display()
	{
		System.out.println("Id is "+ id);
		System.out.println("Name is "+name);
	}
}
public class constructors1 {

	public static void main(String[] args) {
		details d= new details(1,"Yuvraj");
		
		d.display();

	}

}
