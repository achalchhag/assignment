//Implement runtime polymorphism by overriding methods in the child class
package assignmet;

class calc{
	public int add(int a,int b) {
		return a+b;
	}
	public void name()
	{
		System.out.println("In A class");
	}
}

class calc1 extends calc{
	
	public int add(int a,int b) {
		return a+b+1;
	}
	
}
public class Inheritance2 {

	public static void main(String[] args) {
		calc1 c=new calc1();
		int total=c.add(3,4);
		
		System.out.println("Addition is "+ total);


	}

}
