//Write a program that demonstrates the use of an ArrayList and LinkedList.
package assignmet;

import java.util.ArrayList;
import java.util.LinkedList;

public class Collectionsframework1 {

	public static void main(String[] args) {
		System.out.println("Array list");
		ArrayList<String> a= new ArrayList<String>();
		a.add("Java");
		a.add("Java1");
		a.add("Java2");
		
		for(String s:a) {
			System.out.println(s);
		}
		
		System.out.println("Linked List");
		
		LinkedList<String> l=new LinkedList<String>();
		l.add("Hello");
		l.add("Hello1");
		l.add("Hello3");
		
		for(String s1:l) {
			System.out.println(s1);
		}

	}
	
	

}
