//Create a program to reverse a string and check for palindromes
package assignmet;

public class array2 {

	public static void main(String[] args) {
		String str="Hello";
		String rstr="";
		char ch;
		for(int i=0;i<str.length();i++)
		{
			ch= str.charAt(i);
			rstr=ch + rstr;
		}
		System.out.println("Original String is "+str);
		System.out.println("Reversed string = "+rstr);
		
		if(str.equals(rstr)) {
			System.out.println("The String is a pallindrome");
		}
		else
		{
			System.out.println("The String is not a pallindrome");
		}
		
	}

}
