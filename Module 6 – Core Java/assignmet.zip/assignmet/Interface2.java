//o Write a program that implements multiple interfaces in a single class.
package assignmet;

public class Interface2 implements bank,bank1 {

	public static void main(String[] args) {
		Interface2 i= new Interface2();
		i.data();
		i.data1();
		

	}

	@Override
	public void data1() {
		System.out.println("Account number: 9922334456");
		
	}

	@Override
	public void data() {
		System.out.println("Bank Name: HDFC");
		
	}
}

interface bank{
	public void data();
}

interface bank1{
	public void data1();
}


