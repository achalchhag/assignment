// Implement a simple class with getters and setters for encapsulation.
package assignmet;

public class CO3 {
	private int id;
	private String uname;
	private String pass;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getUname() {
		return uname;
	}
	public void setUname(String uname) {
		this.uname = uname;
	}
	public String getPass() {
		return pass;
	}
	public void setPass(String pass) {
		this.pass = pass;
	}


	public static void main(String[] args) {
		CO3 c=new CO3();
		c.setId(1);
		c.setUname("Mahesh");
		c.setPass("mahesh1234");
		
		System.out.println(c.getId() + " "+ c.getUname()+ " "+ c.getPass());

	}
	
}
