// Create a user-defined package and import it into another program.
package assignmet;

public class Packages1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
