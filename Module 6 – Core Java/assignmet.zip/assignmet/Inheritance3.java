//Use the super keyword to call the parent class constructor and methods
package assignmet;
class Aparent{
	public Aparent() {
		System.out.println("This is a parent class constructor");
	}
	public void display(){
		System.out.println("This is a method of Parent Class");
		
	}
}

class Achild extends Aparent{
	public Achild() {
		System.out.println("This is a Child class constructor");
	}
	public void display()
	{
		super.display();
		System.out.println("This is a method of Child class");
	}
	
}
public class Inheritance3 {

	public static void main(String[] args) {
		Achild c= new Achild();
		c.display();
	

	}

}
