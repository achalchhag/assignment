// Write a program to read input from the console using Scanner.

package assignmet;

public class JavaInputOutput1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
