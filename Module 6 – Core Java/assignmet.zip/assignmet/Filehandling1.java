//Write a program to read and write content to a file using FileReader and FileWriter.
package assignmet;

public class Filehandling1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
