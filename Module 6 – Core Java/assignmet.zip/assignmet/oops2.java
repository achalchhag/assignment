//Create a class hierarchy and demonstrate multilevel inheritance.
package assignmet;

class parent {
 public void display() {
     System.out.println("This is Parent Class");
 }
}
class childs1 extends parent {
 public void child1() {
     System.out.println("This is 1st Child Class");
 }
}
class childs2 extends childs1 {
 public void child2() {
     System.out.println("This is 2nd Child Class");
 }
}
public class oops2{
 public static void main(String[] args) {
     childs2 c1 = new childs2();
     c1.display();
     c1.child1();
     c1.child2();
 }
}
