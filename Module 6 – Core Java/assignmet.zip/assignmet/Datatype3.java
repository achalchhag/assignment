//o Demonstrate type casting (explicit and implicit).
package assignmet;

public class Datatype3 {

	public static void main(String[] args) {
		int num=10;
		long num1=num;
		System.out.println("Implicite Casting: ");
		System.out.println("Int value"+ " "+num);
		System.out.println("Long Value"+" "+num1);
		
		double num2=3.14;
		int num3=(int)num2;
		System.out.println("Explicite Casting");
		System.out.println("Double Value"+" "+num2);
		System.out.println("Int value"+" "+num3);
		

	}

}
