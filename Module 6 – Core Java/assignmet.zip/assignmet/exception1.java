//Write a program to demonstrate exception handling using try-catch-finally
package assignmet;

public class exception1 {

	public static void main(String[] args) {
		try {
			int a =5/0;
			System.out.println(a);
			
		} catch (Exception e) {
			System.out.println("Cannot divide by zero");
		}

	}

}
