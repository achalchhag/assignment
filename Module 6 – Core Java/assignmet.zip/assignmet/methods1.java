// Write a program to find the maximum of three numbers using a method.
package assignmet;

public class methods1 {

	public static void main(String[] args) {
		
		int n1=10;
		int n2=5;
		int n3=25;
		
		int max=findmax(n1,n2,n3);
		System.out.println("The maximum number is  "+max);

	}
	
	public static int findmax(int a,int b,int c)
	{
		int max=a;
		
		if(b>max)
		{
			max=b;
		}
		if(c>max)
		{
			max=c;
		}
		return max;
	}

}
