// Demonstrate constructor overloading by passing different types of parameters.
package assignmet;

public class constructor2 {
	public constructor2(String s)
	{
		System.out.println(s);
	}
	
	public constructor2(int id,String name)
	{
		System.out.println("Id is "+ id+" Name "+name);
	}
	
	public void display()
	{
		System.out.println();
	}
	public static void main(String[] args) {
		constructor2 c=new constructor2("Hello");
		c.display();
		constructor2 c1=new constructor2(1,"Yuvraj");
		c1.display();

	}

}
