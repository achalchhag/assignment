//Create a class Student with attributes (name, age) and a method to display the details:
package assignmet;

public class CO1 {

	public static void main(String[] args) {
		Student s=new Student("Yuvraj",20);
		Student s1=new Student("Smeet",21);
		
		s.display();
		s1.display();

	}

}

class Student
{
	String name;
	int age;
	
	public Student(String name,int age) {
		this.name=name;
		this.age=age;
	}
	
	public void display()
	{
		System.out.println(name + " " +age);
	}
}
