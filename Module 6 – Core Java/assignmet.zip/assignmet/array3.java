//o Implement string comparison using equals() and compareTo() methods.
package assignmet;

public class array3 {

	public static void main(String[] args) {
		String str1= "Hello";
		String str2= "Hello";
		
		System.out.println("Equals method");
		System.out.println(str1.equals(str2));
		
		System.out.println("Compare method");
		System.out.println(str1.compareTo(str2));

	}

}
