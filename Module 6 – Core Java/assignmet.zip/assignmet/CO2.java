//Create multiple constructors in a class and demonstrate constructor overloading
package assignmet;

public class CO2 {
	private int id;
	private String name;
	private int age;
	public CO2() {
		System.out.println("Default Constructor");
	}
	public CO2(int id) {
		this.id= id;
		
	}
	public CO2(String name,int age)
	{
		this.name=name;
		this.age=age;
	}
	
	public void display()
	{
		System.out.println(id+" "+name+" "+age);
	}

	public static void main(String[] args) {
		CO2 c1=new CO2();
		c1.display();
		
		CO2 c2=new CO2(1);
		c2.display();
		
		CO2 c3=new CO2("Yuvraj",20);
		c3.display();
		
		

	}

}
