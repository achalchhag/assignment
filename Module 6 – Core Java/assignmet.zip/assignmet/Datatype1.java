//Write a program to demonstrate the use of different data types.
package assignmet;

public class Datatype1 {

	public static void main(String[] args) {
		int age=20;
		System.out.println("Age"+" "+age);
		
		double number=992299886;
		System.out.println("number"+" "+ number);
		
		char char1='A';
		System.out.println("Char"+" "+ char1);
		
		boolean a=true;
		System.out.println("Boolean"+ " "+a);
		
		long number1=10000000;
		System.out.println("Long "+ " "+number1);
		
		short number2=2025;
		System.out.println("Short"+ " "+number2);
		
		byte number3=100;
		System.out.println("Byte"+ " "+number3);
	
	}

}
