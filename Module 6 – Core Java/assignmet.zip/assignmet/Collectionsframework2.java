//Implement a program using HashSet to remove duplicate elements from a list.
package assignmet;

import java.util.ArrayList;
import java.util.HashSet;

public class Collectionsframework2 {

	public static void main(String[] args) {
		ArrayList<String> ls=new ArrayList<String>();
		ls.add("Hello");
		ls.add("Hello1");
		ls.add("HELLO2");
		ls.add("Hello");
		System.out.println("Original list");
		for (String s1:ls)
		{
			System.out.println(s1);	
		}
		System.out.println("Duplicate List");
		HashSet<String> h= new HashSet<>(ls);
		for(String s2:h)
		{
			System.out.println(s2);
		}

	}

}
