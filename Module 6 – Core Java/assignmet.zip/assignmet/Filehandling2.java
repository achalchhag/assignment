//Implement a program that reads a file line by line using BufferedReader
package assignmet;

public class Filehandling2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
