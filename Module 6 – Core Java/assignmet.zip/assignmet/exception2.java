//o Implement multiple catch blocks for different types of exceptions.
package assignmet;

public class exception2 {

	public static void main(String[] args) {
		System.out.println("java");
		System.out.println("Java1");
		int a[]=new int[3];
		try {
			a[0]=10;
			a[1]=20;
			a[2]=30;
			a[3]=40;
			System.out.println(a[0]);
			
		} catch (ArrayIndexOutOfBoundsException e) {
			System.out.println("Array is full");
		}catch(ArithmeticException e) {
			System.out.println("Arithmatic expection");
		}finally {
			System.out.println("All good");
		}
		

	}
}
