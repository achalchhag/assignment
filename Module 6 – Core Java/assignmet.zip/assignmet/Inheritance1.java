//Write a program that demonstrates inheritance using extends keyword
package assignmet;

class Parents{
	public void parent()
	{
		System.out.println("This is parent class");
	}
}
class Childs extends Parents{
	public void child() {
		System.out.println("This is child class");
	}
}
public class Inheritance1 {

	public static void main(String[] args) {
		Childs c=new Childs();
		c.child();
		c.parent();

	}

}
