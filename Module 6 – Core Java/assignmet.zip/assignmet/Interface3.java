// Implement an interface for a real-world example,such as a payment gateway.
package assignmet;

public class Interface3 implements payment{
	private boolean status;

	public static void main(String[] args) {
		Interface3 i=new Interface3();
		i.paymentprocess(50);
		i.paymentstatus();

	}

	@Override
	public void paymentprocess(double amt) {
		System.out.println("Processing  payment of "+amt);
		status= true;
	}

	@Override
	public void paymentstatus() {
		if(status) {
			System.out.println("Payment Successful");
		}
		else
		{
			System.out.println("Payment Not Successful");
		}
		
	}

}

interface payment{
	public void paymentprocess(double amt);
	
	public void paymentstatus();
}
