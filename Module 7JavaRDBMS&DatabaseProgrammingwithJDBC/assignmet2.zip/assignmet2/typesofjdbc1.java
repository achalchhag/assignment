//Create a program that inserts, updates, selects, and deletes data using Statement
package assignmet2;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class typesofjdbc1 {
	public static void main(String[] args) {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			System.out.println("Class not found");
		}
		Connection cn=null;
		try {
			cn=DriverManager.getConnection("jdbc:mysql://localhost/demo","root","");
		} catch (SQLException e) {
			System.out.println("class not found");
		}
		
		String datainsert = "insert into test(name,age) values(?,?)";
		try {
			PreparedStatement ps = cn.prepareStatement(datainsert);
			ps.setString(1,"Mukesh");
			ps.setInt(2, 24);
			int a=ps.executeUpdate();
			if (a>0)
			{
				System.out.println("Data Inserted");
			}
		} catch (SQLException e) {
			System.out.println("Data not inserted");
		}
		
		String datafetch="select * from test where id=4";
		Statement smt=null;
		
		try {
			smt=cn.createStatement();
		} catch (SQLException e) {
			System.out.println("Smt not workng");
		}
		
		ResultSet rs=null;
		try {
			rs=smt.executeQuery(datafetch);
		} catch (SQLException e) {
			System.out.println("Data not found");
		}
		try {
			while(rs.next())
			{
				System.out.println(rs.getInt(1)+" "+rs.getString(2)+" "+rs.getInt(3));
				
			}
		} catch (SQLException e) {
			System.out.println("Data not fetch");
		}

	}	
}
