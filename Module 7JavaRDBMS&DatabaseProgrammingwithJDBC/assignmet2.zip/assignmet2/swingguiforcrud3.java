//o On button clicks, the program should interact with the database and perform the appropriate operation (insert, update, display records, or delete records)
package assignmet2;

public class swingguiforcrud3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
