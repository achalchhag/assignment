//Write a Java program to establish a connection to a database and print a confirmation message upon successful connection.
package assignmet2;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class createjdbcsteps {

	public static void main(String[] args) {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			System.out.println("Connectection established");
		} catch (ClassNotFoundException e) {
			System.out.println("Connection not found");
		}
		
		try {
			Connection cn=DriverManager.getConnection("jdbc:mysql://localhost/demo","root","");
			System.out.println("Successfully Connected to database");
		} catch (SQLException e) {
			System.out.println("Connection not found");
		}
		
	}

}
