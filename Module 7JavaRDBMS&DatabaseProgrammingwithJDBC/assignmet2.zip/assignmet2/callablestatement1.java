//o Create a stored procedure in MySQL with IN and OUT parameters (e.g., a procedure that takes an employee ID as input and returns the employee's full name as output)
package assignmet2;

public class callablestatement1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
