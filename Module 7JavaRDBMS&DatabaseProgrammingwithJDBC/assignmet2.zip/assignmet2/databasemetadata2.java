//o Display database name, version, list of tables, and supported SQL features.
	
package assignmet2;

public class databasemetadata2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
