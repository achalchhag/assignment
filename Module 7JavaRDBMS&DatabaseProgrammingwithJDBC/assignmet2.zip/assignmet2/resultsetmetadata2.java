//o Use a SELECT query to display this metadata for a specific table
package assignmet2;

public class resultsetmetadata2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
