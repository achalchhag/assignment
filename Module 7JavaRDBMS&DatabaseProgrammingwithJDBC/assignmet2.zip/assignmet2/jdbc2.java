//Demonstrate the process of loading a JDBC driver and establishing a connection
package assignmet2;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class jdbc2 {

	public static void main(String[] args) {
		
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			System.out.println("MySql Succesfully Connected");
		} catch (ClassNotFoundException e) {
			System.out.println("Class not found");
		}
		Connection cn=null;
		try {
			cn=DriverManager.getConnection("jdbc:mysql://localhost/demo","root","");
		} catch (SQLException e) {
			System.out.println("Database not connected");
		}

	}

}
