//o Modify the program to use PreparedStatement for parameterized queries.

package assignmet2;

public class typesofjdbc2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
