// Write a program that executes a SELECT query and processes the ResultSet to display records from the database.
package assignmet2;

public class resultsetinterface1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
