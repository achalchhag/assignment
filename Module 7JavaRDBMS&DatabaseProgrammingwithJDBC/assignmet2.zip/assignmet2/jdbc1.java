//Write a simple Java program to connect to a MySQL database using JDBC.
package assignmet2;
public class jdbc1 {

	public static void main(String[] args) {
		
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			System.out.println("Successfully connected");
		} catch (ClassNotFoundException e) {
			System.out.println("Connection not found");
		}
	}

}
