//o Write a program that retrieves and displays column names, types, and count of a ResultSet using ResultSetMetaData.
package assignmet2;

public class resultsetmetadata1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
