//Write SQL queries for:Inserting a record into a table. Updating specific fields of a record. Selecting records based on certain conditions. Deleting specific record
package assignmet2;

public class praticalsqlquerryexample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
