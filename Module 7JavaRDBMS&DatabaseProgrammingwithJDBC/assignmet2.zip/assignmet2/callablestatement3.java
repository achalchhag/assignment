//o Demonstrate how to pass IN parameters and retrieve OUT parameters.
package assignmet2;

public class callablestatement3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
