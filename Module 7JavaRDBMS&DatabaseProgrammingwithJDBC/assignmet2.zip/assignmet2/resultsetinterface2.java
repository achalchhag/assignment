//o Demonstrate how to navigate through the ResultSet using methods like next(), previous(), etc.
package assignmet2;

public class resultsetinterface2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
