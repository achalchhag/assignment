//o Write a Java program that uses CallableStatement to call this stored procedure.

package assignmet2;

public class callablestatement2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
