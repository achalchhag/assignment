//o Identify which driver your Java program uses to connect to MySQL.
package assignmet2;

public class jdbcdrivertype1 {

	public static void main(String[] args) {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			System.out.println("com.mysql.cj.jdbc.Driver is used");
		} catch (ClassNotFoundException e) {
			System.out.println("Driver not found");
		}

	}

}
