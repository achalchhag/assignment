//o Implement CRUD operations (Insert, Update, Select, Delete) using JDBC and MySQL.

package assignmet2;

public class swingguiforcrud2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
