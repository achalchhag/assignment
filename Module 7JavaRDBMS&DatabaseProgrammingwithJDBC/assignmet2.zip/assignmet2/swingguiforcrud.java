//o Create a simple Swing GUI with input fields for id, fname, lname, and email.
package assignmet2;

public class swingguiforcrud {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
