//Write a Java program that performs the following CRUD operations:  Insert a new record. Update an existing record. Select and display records. Delete a record from the database
package assignmet2;

public class jdbccrud {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
