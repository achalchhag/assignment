//Write a program that retrieves and displays metadata information about your database using DatabaseMetaData
package assignmet2;

public class databasemetadata {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
